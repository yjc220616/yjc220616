#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <cmath>
#include <algorithm>
#include <iomanip>

// 坐标结构
template <typename T>
struct Point {
    T x, y;
    
    Point(T x = 0, T y = 0) : x(x), y(y) {}
    
    bool operator==(const Point& other) const {
        return x == other.x && y == other.y;
    }
    
    bool operator!=(const Point& other) const {
        return !(*this == other);
    }
};

// 为Point结构特化哈希函数，使其能在unordered_map中使用
template <typename T>
struct PointHash {
    size_t operator()(const Point<T>& p) const {
        return std::hash<T>()(p.x) ^ (std::hash<T>()(p.y) << 1);
    }
};

// Node类 - A*算法中的节点
struct Node {
    Point<int> position;
    Node* parent;
    int g; // 从起点到当前节点的代价
    int h; // 从当前节点到目标的估计代价
    int f; // 总代价 f = g + h
    
    Node(Point<int> pos = Point<int>(), Node* parent = nullptr) 
        : position(pos), parent(parent), g(0), h(0), f(0) {}
    
    // 用于优先队列的比较运算符
    bool operator>(const Node& other) const {
        return f > other.f;
    }
};

// 启发式函数类
class Heuristic {
public:
    // 曼哈顿距离
    static int manhattan(const Point<int>& a, const Point<int>& b) {
        return std::abs(a.x - b.x) + std::abs(a.y - b.y);
    }
    
    // 欧几里得距离
    static int euclidean(const Point<int>& a, const Point<int>& b) {
        int dx = a.x - b.x;
        int dy = a.y - b.y;
        return static_cast<int>(std::sqrt(dx * dx + dy * dy));
    }
    
    // 切比雪夫距离
    static int chebyshev(const Point<int>& a, const Point<int>& b) {
        return std::max(std::abs(a.x - b.x), std::abs(a.y - b.y));
    }
};

// 地图类
class Map {
private:
    std::vector<std::vector<int>> grid;
    int width, height;
    
public:
    Map(int width, int height) : width(width), height(height) {
        grid.resize(height, std::vector<int>(width, 0));
    }
    
    Map(const std::vector<std::vector<int>>& grid) : grid(grid) {
        height = grid.size();
        width = height > 0 ? grid[0].size() : 0;
    }
    
    // 检查坐标是否在地图范围内
    bool isWithinBounds(const Point<int>& pos) const {
        return pos.x >= 0 && pos.x < width && pos.y >= 0 && pos.y < height;
    }
    
    // 检查该位置是否可以通过
    bool isWalkable(const Point<int>& pos) const {
        return isWithinBounds(pos) && grid[pos.y][pos.x] == 0;
    }
    
    // 获取相邻节点（8个方向）
    std::vector<Point<int>> getNeighbors(const Point<int>& pos) const {
        std::vector<Point<int>> neighbors;
        static const int directions[8][2] = {
            {-1, -1}, {-1, 0}, {-1, 1},
            {0, -1},          {0, 1},
            {1, -1},  {1, 0},  {1, 1}
        };
        
        for (auto& dir : directions) {
            Point<int> neighbor(pos.x + dir[0], pos.y + dir[1]);
            if (isWithinBounds(neighbor)) {
                neighbors.push_back(neighbor);
            }
        }
        
        return neighbors;
    }
    
    // 设置障碍
    void setObstacle(const Point<int>& pos) {
        if (isWithinBounds(pos)) {
            grid[pos.y][pos.x] = 1;
        }
    }
    
    // 绘制地图和路径
    void draw(const std::vector<Point<int>>& path = {}) const {
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                Point<int> current(x, y);
                
                // 检查是否在路径中
                auto it = std::find(path.begin(), path.end(), current);
                if (it != path.end()) {
                    std::cout << "* ";
                } else if (grid[y][x] == 1) {
                    std::cout << "# ";
                } else {
                    std::cout << ". ";
                }
            }
            std::cout << std::endl;
        }
    }
    
    int getWidth() const { return width; }
    int getHeight() const { return height; }
};

// A*算法实现
class AStar {
private:
    const Map& map;
    
public:
    AStar(const Map& map) : map(map) {}
    
    // Find path
    std::vector<Point<int>> findPath(const Point<int>& start, const Point<int>& goal) {
        // Check if start and goal are valid
        if (!map.isWalkable(start) || !map.isWalkable(goal)) {
            std::cerr << "Start or goal point is not walkable!" << std::endl;
            return {};
        }
        
        // Priority queue - sorted by f value
        std::priority_queue<Node, std::vector<Node>, std::greater<Node>> openList;
        
        // All nodes that have been created
        std::unordered_map<Point<int>, Node*, PointHash<int>> allNodes;
        
        // Create start node
        Node* startNode = new Node(start);
        startNode->h = Heuristic::manhattan(start, goal);
        startNode->f = startNode->g + startNode->h;
        
        openList.push(*startNode);
        allNodes[start] = startNode;
        
        // Start searching
        while (!openList.empty()) {
            // Get node with smallest f value
            Node current = openList.top();
            openList.pop();
            
            // If reached goal, reconstruct path
            if (current.position == goal) {
                return reconstructPath(allNodes[goal]);
            }
            
            // Mark as visited
            allNodes[current.position]->g = -1; // 用-1标记已访问
            
            // Check all neighbors
            std::vector<Point<int>> neighbors = map.getNeighbors(current.position);
            for (const auto& neighborPos : neighbors) {
                // If neighbor is not walkable
                if (!map.isWalkable(neighborPos)) {
                    continue;
                }
                
                // Calculate movement cost
                int moveCost = Heuristic::manhattan(current.position, neighborPos) == 1 ? 10 : 14; // 直线10，对角线14
                int newG = current.g + moveCost;
                
                // Check if neighbor is already in nodes map
                auto it = allNodes.find(neighborPos);
                if (it == allNodes.end() || (it->second->g != -1 && newG < it->second->g)) {
                    // Create or update neighbor node
                    Node* neighborNode;
                    if (it == allNodes.end()) {
                        neighborNode = new Node(neighborPos, allNodes[current.position]);
                        allNodes[neighborPos] = neighborNode;
                    } else {
                        neighborNode = it->second;
                        neighborNode->parent = allNodes[current.position];
                    }
                    
                    // Update costs
                    neighborNode->g = newG;
                    neighborNode->h = Heuristic::manhattan(neighborPos, goal);
                    neighborNode->f = neighborNode->g + neighborNode->h;
                    
                    // If not in openList, add to queue
                    if (it == allNodes.end()) {
                        openList.push(*neighborNode);
                    } else {
                        // Since priority queue can't be updated, recreate it
                        // 这是一个简单的解决方案，但对于大型地图效率不高
                        std::priority_queue<Node, std::vector<Node>, std::greater<Node>> newOpenList;
                        while (!openList.empty()) {
                            Node temp = openList.top();
                            openList.pop();
                            if (temp.position != neighborPos) {
                                newOpenList.push(temp);
                            }
                        }
                        newOpenList.push(*neighborNode);
                        openList = std::move(newOpenList);
                    }
                }
            }
        }
        
        // No path found
        std::cerr << "Path not found!" << std::endl;
        
        // Clean up memory
        for (auto& pair : allNodes) {
            delete pair.second;
        }
        
        return {};
    }
    
private:
    // Reconstruct path
    std::vector<Point<int>> reconstructPath(Node* goalNode) {
        std::vector<Point<int>> path;
        Node* current = goalNode;
        
        // Trace back from goal to start
        while (current != nullptr) {
            path.push_back(current->position);
            current = current->parent;
        }
        
        // Reverse path to get from start to goal
        std::reverse(path.begin(), path.end());
        
        return path;
    }
};

int main() {
    // 创建地图
    std::vector<std::vector<int>> grid = {
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 1, 1, 1, 0, 1, 1, 1, 1, 0},
        {0, 1, 0, 0, 0, 0, 0, 0, 1, 0},
        {0, 1, 0, 1, 1, 1, 1, 0, 1, 0},
        {0, 1, 0, 0, 0, 0, 0, 0, 1, 0},
        {0, 1, 1, 1, 0, 1, 1, 1, 1, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };
    
    Map map(grid);
    
    // 定义起点和终点
    Point<int> start(0, 0);
    Point<int> goal(9, 6);
    
    // 创建A*实例并查找路径
    AStar astar(map);
    std::vector<Point<int>> path = astar.findPath(start, goal);
    
    // 绘制地图和路径
    std::cout << "Map and Path:" << std::endl;
    map.draw(path);
    
    // 输出路径信息
    if (!path.empty()) {
        std::cout << "\nPath found! Length: " << path.size() << " steps" << std::endl;
        std::cout << "Path:" << std::endl;
        for (size_t i = 0; i < path.size(); ++i) {
            std::cout << "(" << path[i].x << ", " << path[i].y << ")";
            if (i != path.size() - 1) {
                std::cout << " -> ";
            }
        }
        std::cout << std::endl;
    }
    
    return 0;
}