# A* Path Planner for ROS

This package implements the A* path planning algorithm for ROS.

## Features

- A* algorithm with 8-direction movement support
- Manhattan, Euclidean, and Chebyshev heuristic functions
- ROS integration for map subscription and path publishing
- Rviz visualization support

## Installation

1. Clone this package into your ROS workspace src directory:
   ```bash
   cd ~/catkin_ws/src
   git clone <repository_url>
   ```

2. Build the package:
   ```bash
   cd ~/catkin_ws
   catkin_make
   source devel/setup.bash
   ```

## Usage

1. Launch your map server to publish the map:
   ```bash
   rosrun map_server map_server <your_map_file>.yaml
   ```

2. Run the A* path planner node:
   ```bash
   rosrun astar_ros astar_node
   ```

3. Visualize the path in Rviz:
   ```bash
   rosrun rviz rviz -d <path_to_this_package>/rviz_config.rviz
   ```

## Configuration

- The start and goal positions are defined in `astar_node.cpp`
- You can modify the heuristic function in `astar.cpp`
- The map resolution and origin are automatically obtained from the map message

## Nodes

### astar_node

**Subscribes to:**
- `/map` (nav_msgs/OccupancyGrid) - The environment map

**Publishes to:**
- `/astar_path` (nav_msgs/Path) - The planned path

## File Structure

- `src/astar.h` - Header file with data structures and class declarations
- `src/astar.cpp` - Implementation of the A* algorithm
- `src/astar_node.cpp` - ROS node implementation
- `map.yaml` - Example map configuration
- `rviz_config.rviz` - Rviz configuration for visualization

## Notes

- The node automatically runs the path planning algorithm when a map is received
- The path is published in the `map` coordinate frame
- The algorithm supports diagonal movement with a cost of 14 (straight movement cost is 10)

## License

MIT
