#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include "astar.h"

class AStarNode {
private:
    ros::NodeHandle nh_;
    ros::Subscriber map_sub_;
    ros::Publisher path_pub_;
    
    Map map_;
    bool map_received_;
    
    // 起点和终点坐标（以地图格子为单位）
    Point<int> start_;
    Point<int> goal_;
    
    // 地图分辨率
    float map_resolution_;
    // 地图原点
    geometry_msgs::Pose map_origin_;
    
public:
    AStarNode() : map_received_(false), map_resolution_(0.0) {
        // 订阅地图
        map_sub_ = nh_.subscribe("/map", 1, &AStarNode::mapCallback, this);
        
        // 发布路径
        path_pub_ = nh_.advertise<nav_msgs::Path>("/astar_path", 1);
        
        // 初始化起点和终点（可根据需要修改）
        start_ = Point<int>(0, 0);
        goal_ = Point<int>(9, 6);
        
        ROS_INFO("A* Path Planner Node Initialized");
    }
    
    // 地图回调函数
    void mapCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg) {
        ROS_INFO("Received Map");
        
        // 保存地图信息
        map_resolution_ = msg->info.resolution;
        map_origin_ = msg->info.origin;
        
        // 获取地图尺寸
        int width = msg->info.width;
        int height = msg->info.height;
        
        // 将ROS地图转换为我们的Map类格式
        std::vector<std::vector<int>> grid(height, std::vector<int>(width, 0));
        
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                int index = y * width + x;
                int value = msg->data[index];
                
                // OccupancyGrid的data中：0-100表示占用概率，-1表示未知
                // 我们将>50的视为障碍物
                if (value > 50) {
                    grid[y][x] = 1; // 障碍物
                } else {
                    grid[y][x] = 0; // 可通行
                }
            }
        }
        
        // 更新地图
        map_ = Map(grid);
        map_received_ = true;
        
        // 运行A*算法
        findPath();
    }
    
    // 运行A*算法并发布路径
    void findPath() {
        if (!map_received_) {
            ROS_WARN("Map not received yet");
            return;
        }
        
        // 创建A*算法实例
        AStar astar(map_);
        
        // 运行A*算法
        std::vector<Point<int>> path = astar.findPath(start_, goal_);
        
        if (path.empty()) {
            ROS_WARN("No path found");
            return;
        }
        
        ROS_INFO("Path found with %d steps", (int)path.size());
        
        // 将路径转换为ROS消息
        nav_msgs::Path path_msg;
        path_msg.header.stamp = ros::Time::now();
        path_msg.header.frame_id = "map";
        
        for (const auto& point : path) {
            geometry_msgs::PoseStamped pose;
            pose.header = path_msg.header;
            
            // 将地图格子坐标转换为实际坐标
            pose.pose.position.x = point.x * map_resolution_ + map_origin_.position.x;
            pose.pose.position.y = point.y * map_resolution_ + map_origin_.position.y;
            pose.pose.position.z = 0.0;
            
            // 朝向（这里简单设置为0）
            pose.pose.orientation.w = 1.0;
            
            path_msg.poses.push_back(pose);
        }
        
        // 发布路径
        path_pub_.publish(path_msg);
        ROS_INFO("Path published");
    }
    
    // 设置起点和终点
    void setStartGoal(const Point<int>& start, const Point<int>& goal) {
        start_ = start;
        goal_ = goal;
        ROS_INFO("Start: (%d, %d), Goal: (%d, %d)", start.x, start.y, goal.x, goal.y);
    }
};

int main(int argc, char** argv) {
    // 初始化ROS节点
    ros::init(argc, argv, "astar_node");
    
    // 创建AStarNode实例
    AStarNode astar_node;
    
    // 运行节点
    ros::spin();
    
    return 0;
}
