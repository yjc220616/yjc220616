#ifndef ASTAR_H
#define ASTAR_H

#include <vector>
#include <queue>
#include <unordered_map>
#include <cmath>
#include <algorithm>

// 坐标结构
template <typename T>
struct Point {
    T x, y;
    
    Point(T x = 0, T y = 0) : x(x), y(y) {}
    
    bool operator==(const Point& other) const {
        return x == other.x && y == other.y;
    }
    
    bool operator!=(const Point& other) const {
        return !(*this == other);
    }
};

// 为Point结构特化哈希函数，使其能在unordered_map中使用
template <typename T>
struct PointHash {
    size_t operator()(const Point<T>& p) const {
        return std::hash<T>()(p.x) ^ (std::hash<T>()(p.y) << 1);
    }
};

// Node类 - A*算法中的节点
struct Node {
    Point<int> position;
    Node* parent;
    int g; // 从起点到当前节点的代价
    int h; // 从当前节点到目标的估计代价
    int f; // 总代价 f = g + h
    
    Node(Point<int> pos = Point<int>(), Node* parent = nullptr) 
        : position(pos), parent(parent), g(0), h(0), f(0) {}
    
    // 用于优先队列的比较运算符
    bool operator>(const Node& other) const {
        return f > other.f;
    }
};

// 启发式函数类
class Heuristic {
public:
    // 曼哈顿距离
    static int manhattan(const Point<int>& a, const Point<int>& b);
    
    // 欧几里得距离
    static int euclidean(const Point<int>& a, const Point<int>& b);
    
    // 切比雪夫距离
    static int chebyshev(const Point<int>& a, const Point<int>& b);
};

// 地图类
class Map {
private:
    std::vector<std::vector<int>> grid;
    int width, height;
    
public:
    Map(int width, int height);
    Map(const std::vector<std::vector<int>>& grid);
    
    // 检查坐标是否在地图范围内
    bool isWithinBounds(const Point<int>& pos) const;
    
    // 检查该位置是否可以通过
    bool isWalkable(const Point<int>& pos) const;
    
    // 获取相邻节点（8个方向）
    std::vector<Point<int>> getNeighbors(const Point<int>& pos) const;
    
    // 设置障碍
    void setObstacle(const Point<int>& pos);
    
    // 设置地图数据
    void setGrid(const std::vector<std::vector<int>>& newGrid);
    
    // 获取地图宽度
    int getWidth() const;
    
    // 获取地图高度
    int getHeight() const;
};

// A*算法实现
class AStar {
private:
    const Map& map;
    
    // 重构路径
    std::vector<Point<int>> reconstructPath(Node* goalNode);
    
public:
    AStar(const Map& map);
    
    // 查找路径
    std::vector<Point<int>> findPath(const Point<int>& start, const Point<int>& goal);
};

#endif // ASTAR_H
