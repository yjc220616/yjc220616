#include "astar.h"

// 启发式函数实现
int Heuristic::manhattan(const Point<int>& a, const Point<int>& b) {
    return std::abs(a.x - b.x) + std::abs(a.y - b.y);
}

int Heuristic::euclidean(const Point<int>& a, const Point<int>& b) {
    int dx = a.x - b.x;
    int dy = a.y - b.y;
    return static_cast<int>(std::sqrt(dx * dx + dy * dy));
}

int Heuristic::chebyshev(const Point<int>& a, const Point<int>& b) {
    return std::max(std::abs(a.x - b.x), std::abs(a.y - b.y));
}

// Map类实现
Map::Map(int width, int height) : width(width), height(height) {
    grid.resize(height, std::vector<int>(width, 0));
}

Map::Map(const std::vector<std::vector<int>>& grid) : grid(grid) {
    height = grid.size();
    width = height > 0 ? grid[0].size() : 0;
}

bool Map::isWithinBounds(const Point<int>& pos) const {
    return pos.x >= 0 && pos.x < width && pos.y >= 0 && pos.y < height;
}

bool Map::isWalkable(const Point<int>& pos) const {
    return isWithinBounds(pos) && grid[pos.y][pos.x] == 0;
}

std::vector<Point<int>> Map::getNeighbors(const Point<int>& pos) const {
    std::vector<Point<int>> neighbors;
    static const int directions[8][2] = {
        {-1, -1}, {-1, 0}, {-1, 1},
        {0, -1},          {0, 1},
        {1, -1},  {1, 0},  {1, 1}
    };
    
    for (auto& dir : directions) {
        Point<int> neighbor(pos.x + dir[0], pos.y + dir[1]);
        if (isWithinBounds(neighbor)) {
            neighbors.push_back(neighbor);
        }
    }
    
    return neighbors;
}

void Map::setObstacle(const Point<int>& pos) {
    if (isWithinBounds(pos)) {
        grid[pos.y][pos.x] = 1;
    }
}

void Map::setGrid(const std::vector<std::vector<int>>& newGrid) {
    grid = newGrid;
    height = grid.size();
    width = height > 0 ? grid[0].size() : 0;
}

int Map::getWidth() const {
    return width;
}

int Map::getHeight() const {
    return height;
}

// A*算法实现
AStar::AStar(const Map& map) : map(map) {
}

std::vector<Point<int>> AStar::findPath(const Point<int>& start, const Point<int>& goal) {
    // Check if start and goal are valid
    if (!map.isWalkable(start) || !map.isWalkable(goal)) {
        return {};
    }
    
    // Priority queue - sorted by f value
    std::priority_queue<Node, std::vector<Node>, std::greater<Node>> openList;
    
    // All nodes that have been created
    std::unordered_map<Point<int>, Node*, PointHash<int>> allNodes;
    
    // Create start node
    Node* startNode = new Node(start);
    startNode->h = Heuristic::manhattan(start, goal);
    startNode->f = startNode->g + startNode->h;
    
    openList.push(*startNode);
    allNodes[start] = startNode;
    
    // Start searching
    while (!openList.empty()) {
        // Get node with smallest f value
        Node current = openList.top();
        openList.pop();
        
        // If reached goal, reconstruct path
        if (current.position == goal) {
            std::vector<Point<int>> path = reconstructPath(allNodes[goal]);
            
            // Clean up memory
            for (auto& pair : allNodes) {
                delete pair.second;
            }
            
            return path;
        }
        
        // Mark as visited
        allNodes[current.position]->g = -1; // Use -1 to mark as visited
        
        // Check all neighbors
        std::vector<Point<int>> neighbors = map.getNeighbors(current.position);
        for (const auto& neighborPos : neighbors) {
            // If neighbor is not walkable
            if (!map.isWalkable(neighborPos)) {
                continue;
            }
            
            // Calculate movement cost
            int moveCost = Heuristic::manhattan(current.position, neighborPos) == 1 ? 10 : 14; // Straight 10, diagonal 14
            int newG = current.g + moveCost;
            
            // Check if neighbor is already in nodes map
            auto it = allNodes.find(neighborPos);
            if (it == allNodes.end() || (it->second->g != -1 && newG < it->second->g)) {
                // Create or update neighbor node
                Node* neighborNode;
                if (it == allNodes.end()) {
                    neighborNode = new Node(neighborPos, allNodes[current.position]);
                    allNodes[neighborPos] = neighborNode;
                } else {
                    neighborNode = it->second;
                    neighborNode->parent = allNodes[current.position];
                }
                
                // Update costs
                neighborNode->g = newG;
                neighborNode->h = Heuristic::manhattan(neighborPos, goal);
                neighborNode->f = neighborNode->g + neighborNode->h;
                
                // If not in openList, add to queue
                if (it == allNodes.end()) {
                    openList.push(*neighborNode);
                } else {
                    // Since priority queue can't be updated, recreate it
                    std::priority_queue<Node, std::vector<Node>, std::greater<Node>> newOpenList;
                    while (!openList.empty()) {
                        Node temp = openList.top();
                        openList.pop();
                        if (temp.position != neighborPos) {
                            newOpenList.push(temp);
                        }
                    }
                    newOpenList.push(*neighborNode);
                    openList = std::move(newOpenList);
                }
            }
        }
    }
    
    // No path found
    
    // Clean up memory
    for (auto& pair : allNodes) {
        delete pair.second;
    }
    
    return {};
}

std::vector<Point<int>> AStar::reconstructPath(Node* goalNode) {
    std::vector<Point<int>> path;
    Node* current = goalNode;
    
    // Trace back from goal to start
    while (current != nullptr) {
        path.push_back(current->position);
        current = current->parent;
    }
    
    // Reverse path to get from start to goal
    std::reverse(path.begin(), path.end());
    
    return path;
}
