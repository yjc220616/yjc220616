#include <ros/ros.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>

void startCallback(
    const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg)
{
    ROS_INFO("===== START POSE =====");
    ROS_INFO("seq: %d", msg->header.seq);
    ROS_INFO("stamp: %.3f", msg->header.stamp.toSec());
    ROS_INFO("frame_id: %s", msg->header.frame_id.c_str());

    ROS_INFO("position: (%.3f, %.3f, %.3f)",
        msg->pose.pose.position.x,
        msg->pose.pose.position.y,
        msg->pose.pose.position.z);

    ROS_INFO("orientation: (%.3f, %.3f, %.3f, %.3f)",
        msg->pose.pose.orientation.x,
        msg->pose.pose.orientation.y,
        msg->pose.pose.orientation.z,
        msg->pose.pose.orientation.w);

    // covariance[36] 可完整输出或存储
}
#include <geometry_msgs/PoseStamped.h>

void goalCallback(
    const geometry_msgs::PoseStamped::ConstPtr& msg)
{
    ROS_INFO("===== GOAL POSE =====");
    ROS_INFO("seq: %d", msg->header.seq);
    ROS_INFO("stamp: %.3f", msg->header.stamp.toSec());
    ROS_INFO("frame_id: %s", msg->header.frame_id.c_str());

    ROS_INFO("position: (%.3f, %.3f, %.3f)",
        msg->pose.position.x,
        msg->pose.position.y,
        msg->pose.position.z);

    ROS_INFO("orientation: (%.3f, %.3f, %.3f, %.3f)",
        msg->pose.orientation.x,
        msg->pose.orientation.y,
        msg->pose.orientation.z,
        msg->pose.orientation.w);
}
#include <nav_msgs/Path.h>

void pathCallback(const nav_msgs::Path::ConstPtr& msg)
{
    ROS_INFO("===== PATH =====");
    ROS_INFO("frame_id: %s", msg->header.frame_id.c_str());
    ROS_INFO("pose count: %lu", msg->poses.size());

    for (size_t i = 0; i < msg->poses.size(); ++i)
    {
        const auto& p = msg->poses[i].pose;
        ROS_INFO(" [%lu] (%.2f, %.2f)",
            i, p.position.x, p.position.y);
    }
}
int main(int argc, char** argv)
{
    ros::init(argc, argv, "rviz_io_node");
    ros::NodeHandle nh;

    ros::Subscriber start_sub =
        nh.subscribe("/initialpose", 1, startCallback);

    ros::Subscriber goal_sub =
        nh.subscribe("/move_base_simple/goal", 1, goalCallback);

    ros::Subscriber path_sub =
        nh.subscribe("/plan", 1, pathCallback);

    ros::spin();
    return 0;
}
