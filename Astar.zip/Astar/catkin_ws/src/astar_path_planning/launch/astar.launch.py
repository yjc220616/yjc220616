from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'map_width',
            default_value='50',
            description='Map width in cells'
        ),
        DeclareLaunchArgument(
            'map_height',
            default_value='50',
            description='Map height in cells'
        ),
        DeclareLaunchArgument(
            'map_resolution',
            default_value='0.1',
            description='Map resolution in meters/cell'
        ),
        DeclareLaunchArgument(
            'origin_x',
            default_value='0.0',
            description='Map origin x'
        ),
        DeclareLaunchArgument(
            'origin_y',
            default_value='0.0',
            description='Map origin y'
        ),
        DeclareLaunchArgument(
            'start_x',
            default_value='1.0',
            description='Start position x'
        ),
        DeclareLaunchArgument(
            'start_y',
            default_value='1.0',
            description='Start position y'
        ),
        DeclareLaunchArgument(
            'goal_x',
            default_value='8.0',
            description='Goal position x'
        ),
        DeclareLaunchArgument(
            'goal_y',
            default_value='8.0',
            description='Goal position y'
        ),
        DeclareLaunchArgument(
            'obstacle_ratio',
            default_value='30',
            description='Percentage of obstacles'
        ),
        DeclareLaunchArgument(
            'random_obstacles',
            default_value='true',
            description='Enable random obstacles'
        ),
        Node(
            package='astar_path_planning',
            executable='astar_node',
            name='astar_node',
            output='screen',
            parameters=[{
                'map_width': LaunchConfiguration('map_width'),
                'map_height': LaunchConfiguration('map_height'),
                'map_resolution': LaunchConfiguration('map_resolution'),
                'origin_x': LaunchConfiguration('origin_x'),
                'origin_y': LaunchConfiguration('origin_y'),
                'start_x': LaunchConfiguration('start_x'),
                'start_y': LaunchConfiguration('start_y'),
                'goal_x': LaunchConfiguration('goal_x'),
                'goal_y': LaunchConfiguration('goal_y'),
                'obstacle_ratio': LaunchConfiguration('obstacle_ratio'),
                'random_obstacles': LaunchConfiguration('random_obstacles'),
                'frame_id': 'map'
            }]
        ),
    ])
