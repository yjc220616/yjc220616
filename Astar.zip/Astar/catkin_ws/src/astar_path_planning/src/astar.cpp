#include "astar.h"
#include <iostream>
#include <cmath>

namespace astar_planning {

AStar::AStar(int width, int height, double resolution, double origin_x, double origin_y)
    : width_(width), height_(height), resolution_(resolution), 
      origin_x_(origin_x), origin_y_(origin_y) {
    grid_.resize(width_);
    for (int i = 0; i < width_; ++i) {
        grid_[i].resize(height_);
        for (int j = 0; j < height_; ++j) {
            grid_[i][j] = new Node(i, j);
        }
    }
}

AStar::~AStar() {
    for (int i = 0; i < width_; ++i) {
        for (int j = 0; j < height_; ++j) {
            delete grid_[i][j];
        }
    }
}

Node* AStar::getNode(int x, int y) {
    if (x >= 0 && x < width_ && y >= 0 && y < height_) {
        return grid_[x][y];
    }
    return nullptr;
}

Node* AStar::worldToNode(double wx, double wy) {
    int x = static_cast<int>((wx - origin_x_) / resolution_);
    int y = static_cast<int>((wy - origin_y_) / resolution_);
    return getNode(x, y);
}

std::pair<double, double> AStar::nodeToWorld(Node* node) {
    double wx = origin_x_ + (node->x + 0.5) * resolution_;
    double wy = origin_y_ + (node->y + 0.5) * resolution_;
    return {wx, wy};
}

double AStar::heuristic(Node* a, Node* b) {
    return std::sqrt(std::pow(b->x - a->x, 2) + std::pow(b->y - a->y, 2));
}

std::vector<Node*> AStar::getNeighbors(Node* node) {
    std::vector<Node*> neighbors;
    int dx[8] = {-1, -1, -1, 0, 0, 1, 1, 1};
    int dy[8] = {-1, 0, 1, -1, 1, -1, 0, 1};
    
    for (int i = 0; i < 8; ++i) {
        Node* neighbor = getNode(node->x + dx[i], node->y + dy[i]);
        if (neighbor && !neighbor->obstacle) {
            neighbors.push_back(neighbor);
        }
    }
    return neighbors;
}

std::vector<std::pair<double, double>> AStar::reconstructPath(Node* goal) {
    std::vector<std::pair<double, double>> path;
    Node* current = goal;
    while (current != nullptr) {
        auto world_pos = nodeToWorld(current);
        path.push_back(world_pos);
        current = current->parent;
    }
    std::reverse(path.begin(), path.end());
    return path;
}

void AStar::setObstacles(const std::vector<std::vector<int>>& grid) {
    for (int i = 0; i < width_ && i < static_cast<int>(grid.size()); ++i) {
        for (int j = 0; j < height_ && j < static_cast<int>(grid[i].size()); ++j) {
            if (grid[i][j] == 1) {
                grid_[i][j]->obstacle = true;
            }
        }
    }
}

void AStar::clearObstacles() {
    for (int i = 0; i < width_; ++i) {
        for (int j = 0; j < height_; ++j) {
            grid_[i][j]->obstacle = false;
            grid_[i][j]->g = 0;
            grid_[i][j]->h = 0;
            grid_[i][j]->f = 0;
            grid_[i][j]->parent = nullptr;
        }
    }
}

std::vector<std::pair<double, double>> AStar::findPath(
    double start_x, double start_y,
    double goal_x, double goal_y,
    const std::vector<std::vector<int>>& grid) {
    
    clearObstacles();
    setObstacles(grid);
    
    Node* start = worldToNode(start_x, start_y);
    Node* goal = worldToNode(goal_x, goal_y);
    
    if (!start || !goal || goal->obstacle) {
        std::cout << "Invalid start or goal position" << std::endl;
        return {};
    }
    
    while (!open_set_.empty()) {
        open_set_.pop();
    }
    closed_set_.clear();
    
    open_set_.push(start);
    start->g = 0;
    start->h = heuristic(start, goal);
    start->f = start->g + start->h;
    
    int iterations = 0;
    const int max_iterations = width_ * height_ * 2;
    
    while (!open_set_.empty() && iterations < max_iterations) {
        iterations++;
        Node* current = open_set_.top();
        open_set_.pop();
        
        if (closed_set_.count(current)) {
            continue;
        }
        closed_set_[current] = true;
        
        if (current == goal) {
            return reconstructPath(goal);
        }
        
        std::vector<Node*> neighbors = getNeighbors(current);
        for (Node* neighbor : neighbors) {
            if (closed_set_.count(neighbor)) {
                continue;
            }
            
            double tentative_g = current->g + heuristic(current, neighbor);
            
            bool in_open_set = false;
            std::vector<Node*> temp_queue;
            while (!open_set_.empty()) {
                Node* node = open_set_.top();
                open_set_.pop();
                if (node == neighbor) {
                    in_open_set = true;
                }
                temp_queue.push_back(node);
            }
            for (Node* n : temp_queue) {
                open_set_.push(n);
            }
            
            if (!in_open_set || tentative_g < neighbor->g) {
                neighbor->parent = current;
                neighbor->g = tentative_g;
                neighbor->h = heuristic(neighbor, goal);
                neighbor->f = neighbor->g + neighbor->h;
                open_set_.push(neighbor);
            }
        }
    }
    
    std::cout << "No path found" << std::endl;
    return {};
}

}
