#ifndef ASTAR_H
#define ASTAR_H

#include <vector>
#include <cmath>
#include <queue>
#include <unordered_map>
#include <functional>
#include <limits>

namespace astar_planning {

struct Node {
    int x, y;
    double g, h, f;
    Node* parent;
    bool obstacle;
    
    Node(int x_, int y_) : x(x_), y(y_), g(0), h(0), f(0), parent(nullptr), obstacle(false) {}
    
    bool operator==(const Node& other) const {
        return x == other.x && y == other.y;
    }
};

struct NodeHash {
    size_t operator()(const Node* node) const {
        return std::hash<int>()(node->x * 1000 + node->y);
    }
};

struct NodeCompare {
    bool operator()(const Node* a, const Node* b) const {
        return a->f > b->f;
    }
};

class AStar {
public:
    AStar(int width, int height, double resolution, double origin_x, double origin_y);
    ~AStar();
    
    std::vector<std::pair<double, double>> findPath(
        double start_x, double start_y, 
        double goal_x, double goal_y,
        const std::vector<std::vector<int>>& grid);
    
    void setObstacles(const std::vector<std::vector<int>>& grid);
    void clearObstacles();
    
private:
    Node* getNode(int x, int y);
    Node* worldToNode(double wx, double wy);
    std::pair<double, double> nodeToWorld(Node* node);
    double heuristic(Node* a, Node* b);
    std::vector<Node*> getNeighbors(Node* node);
    std::vector<std::pair<double, double>> reconstructPath(Node* goal);
    
    int width_, height_;
    double resolution_, origin_x_, origin_y_;
    std::vector<std::vector<Node*>> grid_;
    std::priority_queue<Node*, std::vector<Node*>, NodeCompare> open_set_;
    std::unordered_map<Node*, bool, NodeHash> closed_set_;
};

}

#endif
