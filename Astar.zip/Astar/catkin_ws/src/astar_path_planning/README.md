# A* 路径规划算法包

这是一个基于 ROS 1 的 A* 路径规划算法实现，可以在 Rviz 中可视化二维路径。

## 环境要求

- **操作系统**: Ubuntu 20.04 (WSL) 或 Ubuntu 18.04/16.04
- **ROS 版本**: ROS 1 Noetic (Ubuntu 20.04) / Melodic (Ubuntu 18.04) / Kinetic (Ubuntu 16.04)
- **依赖包**:
  - roscpp
  - nav_msgs
  - geometry_msgs
  - visualization_msgs
  - std_msgs

## 安装 ROS 1 Noetic

在 WSL 中执行以下命令：

```bash
# 1. 添加 ROS 软件源
sudo sh -c echo "deb http://packages.ros.org/ros/ubuntu focal main" > /etc/apt/sources.list.d/ros-latest.list

# 2. 下载 ROS 密钥
sudo apt-key adv --keyserver 'hkp://keyserver.ubuntu.com:80' --recv-key C1CF6E31E6BADE82F4E2303CEE80C9C88FD4CBEB

# 3. 更新软件源并安装
sudo apt update
sudo apt install ros-noetic-desktop -y

# 4. 初始化 rosdep
sudo apt install python3-rosdep -y
sudo rosdep init
rosdep update

# 5. 添加环境变量到 ~/.bashrc
echo "source /opt/ros/noetic/setup.bash" >> ~/.bashrc
source ~/.bashrc
```

## 安装步骤

### 1. 创建工作空间

```bash
mkdir -p ~/catkin_ws/src
cd ~/catkin_ws
```

### 2. 复制代码到工作空间

**从 Windows 复制到 WSL:**
```bash
cp -r /mnt/f/Projects/Astar/catkin_ws/src/astar_path_planning ~/catkin_ws/src/
```

### 3. 编译工作空间

```bash
cd ~/catkin_ws
source /opt/ros/noetic/setup.bash
catkin_make
```

### 4. 加载环境

```bash
source devel/setup.bash
```

## 运行算法

### 方法 1: 使用 launch 文件 (推荐)

```bash
cd ~/catkin_ws
source devel/setup.bash
roslaunch astar_path_planning astar.launch
```

### 方法 2: 单独运行节点

```bash
cd ~/catkin_ws
source devel/setup.bash
rosrun astar_path_planning astar_node
```

### 方法 3: 设置参数运行

```bash
cd ~/catkin_ws
source devel/setup.bash
rosrun astar_path_planning astar_node _map_width:=50 _map_height:=50 _start_x:=1.0 _start_y:=1.0 _goal_x:=8.0 _goal_y:=8.0
```

## Rviz 可视化

启动后会看到 Rviz 窗口，显示：
- **灰色区域**: 障碍物地图
- **绿色线**: A* 算法规划的路径
- **绿色球体**: 起点位置
- **红色球体**: 终点位置
- **灰色方块**: 障碍物

### 在 Rviz 中添加显示

1. 启动后点击左下角 **Add** 按钮
2. 选择 **By topic** 选项卡
3. 添加以下显示：
   - `/map` → `Map` - 显示障碍物地图
   - `/path` → `Path` - 显示规划路径
   - `/start_point` → `Marker` - 显示起点
   - `/goal_point` → `Marker` - 显示终点
   - `/obstacles` → `MarkerArray` - 显示障碍物

### 使用 Rviz 配置文件

```bash
cd ~/catkin_ws
source devel/setup.bash
rviz -d src/astar_path_planning/config/astar_rviz.rviz
```

## 项目结构

```
astar_path_planning/
├── CMakeLists.txt              # CMake 构建配置 (catkin)
├── package.xml                 # ROS 包描述文件 (format 2)
├── README.md                   # 本文档
├── include/
│   └── astar.h                 # A* 算法头文件
├── src/
│   ├── astar.cpp               # A* 算法实现
│   └── astar_node.cpp          # ROS 1 节点
├── launch/
│   └── astar.launch            # ROS 1 launch 文件
└── config/
    └── astar_rviz.rviz         # Rviz 配置文件
```

## 代码说明

### A* 算法参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| map_width | 50 | 地图宽度（格子数） |
| map_height | 50 | 地图高度（格子数） |
| map_resolution | 0.1 | 地图分辨率（米/格子） |
| origin_x | 0.0 | 地图原点 X 坐标 |
| origin_y | 0.0 | 地图原点 Y 坐标 |
| start_x | 1.0 | 起点 X 坐标 |
| start_y | 1.0 | 起点 Y 坐标 |
| goal_x | 8.0 | 终点 X 坐标 |
| goal_y | 8.0 | 终点 Y 坐标 |
| obstacle_ratio | 30 | 障碍物比例 (%) |
| random_obstacles | true | 是否随机生成障碍物 |
| frame_id | "map" | 坐标 frame 名称 |

### 发布的话题

| 话题名称 | 类型 | 说明 |
|----------|------|------|
| /map | nav_msgs/OccupancyGrid | 占据地图 |
| /path | nav_msgs/Path | 规划路径 |
| /start_point | visualization_msgs/Marker | 起点标记 |
| /goal_point | visualization_msgs/Marker | 终点标记 |
| /obstacles | visualization_msgs/MarkerArray | 障碍物标记 |
| /replan_command | std_msgs/String | 重规划命令 |

### 订阅的话题

| 话题名称 | 类型 | 说明 |
|----------|------|------|
| /replan_command | std_msgs/String | 接收命令："replan" 重规划，"regenerate" 重新生成地图 |

### 关键文件

| 文件 | 功能 |
|------|------|
| `astar.h/cpp` | A* 核心算法实现，包括节点结构、启发式函数、路径搜索 |
| `astar_node.cpp` | ROS 1 节点，负责地图生成、话题发布、参数管理 |
| `astar.launch` | XML launch 文件，配置参数并启动节点 |

### A* 算法核心类

```cpp
namespace astar_planning {
class AStar {
public:
    AStar(int width, int height, double resolution, double origin_x, double origin_y);
    ~AStar();
    std::vector<std::pair<double, double>> findPath(
        double start_x, double start_y, 
        double goal_x, double goal_y,
        const std::vector<std::vector<int>>& grid);
};
}
```

## 常见问题

### Q: 提示找不到包
**解决**: 确保已执行 `source devel/setup.bash`

### Q: 编译报错缺少依赖
**解决**: 确保已安装 ros-noetic-desktop:
```bash
sudo apt install ros-noetic-desktop -y
```

### Q: Rviz 不显示地图
**解决**: 在 Rviz 中手动添加 Map 显示：
1. 点击左下角 **Add** 按钮
2. 选择 **By topic** 选项卡
3. 选择 `/map` → `Map`

### Q: 想修改起点和终点
**解决**: 在 launch 文件中修改参数，或运行时传入参数：
```bash
roslaunch astar_path_planning astar.launch start_x:=2.0 start_y:=2.0 goal_x:=7.0 goal_y:=7.0
```

### Q: 想要固定障碍物不随机
**解决**: 设置 `random_obstacles:=false`，然后手动修改 grid 数据

## 使用自定义地图

可以在代码中直接设置 grid：
```cpp
// 在 astar_node.cpp 的 generateMap() 函数中
// 将随机生成改为手动设置
grid_[5][5] = 1;  // 在 (5,5) 位置设置障碍物
grid_[10][10] = 1;  // 在 (10,10) 位置设置障碍物
```

## 命令速查表

```bash
# 编译
cd ~/catkin_ws
catkin_make

# 运行 launch 文件
roslaunch astar_path_planning astar.launch

# 运行节点
rosrun astar_path_planning astar_node

# 查看节点列表
rosnode list

# 查看话题列表
rostopic list

# 查看话题消息
rostopic echo /path

# Rviz 可视化
rviz -d src/astar_path_planning/config/astar_rviz.rviz
```

## 参考资料

- [ROS 1 官方文档](http://wiki.ros.org/noetic)
- [roscpp 文档](http://wiki.ros.org/roscpp)
- [Launch 文件文档](http://wiki.ros.org/roslaunch/XML)
- [A* 算法原理](https://en.wikipedia.org/wiki/A*_search_algorithm)

## 作者

- 作者: User
- 邮箱: user@todo.com
- 许可证: MIT
