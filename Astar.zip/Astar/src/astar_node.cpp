#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Point.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <std_msgs/String.h>
#include "astar.h"
#include <vector>
#include <cstdlib>
#include <ctime>
#include <iostream>

class AStarPlanner {
public:
    AStarPlanner() {
        ros::NodeHandle nh("~");
        
        nh.param<int>("map_width", map_width_, 50);
        nh.param<int>("map_height", map_height_, 50);
        nh.param<double>("map_resolution", map_resolution_, 0.1);
        nh.param<double>("origin_x", origin_x_, 0.0);
        nh.param<double>("origin_y", origin_y_, 0.0);
        nh.param<double>("start_x", start_x_, 1.0);
        nh.param<double>("start_y", start_y_, 1.0);
        nh.param<double>("goal_x", goal_x_, 8.0);
        nh.param<double>("goal_y", goal_y_, 8.0);
        nh.param<int>("obstacle_ratio", obstacle_ratio_, 30);
        nh.param<bool>("random_obstacles", random_obstacles_, true);
        nh.param<std::string>("frame_id", frame_id_, "map");
        
        map_pub_ = nh.advertise<nav_msgs::OccupancyGrid>("map", 1, true);
        path_pub_ = nh.advertise<nav_msgs::Path>("path", 1, true);
        start_pub_ = nh.advertise<visualization_msgs::Marker>("start_point", 1, true);
        goal_pub_ = nh.advertise<visualization_msgs::Marker>("goal_point", 1, true);
        obstacles_pub_ = nh.advertise<visualization_msgs::MarkerArray>("obstacles", 1, true);
        
        command_sub_ = nh.subscribe<std_msgs::String>("replan_command", 10, 
            &AStarPlanner::commandCallback, this);
        
        astar_ = new astar_planning::AStar(map_width_, map_height_, 
                                           map_resolution_, origin_x_, origin_y_);
        
        generateMap();
        publishAll();
        
        ROS_INFO("A* Planner initialized");
        ROS_INFO("Start: (%.2f, %.2f)", start_x_, start_y_);
        ROS_INFO("Goal: (%.2f, %.2f)", goal_x_, goal_y_);
    }
    
    ~AStarPlanner() {
        delete astar_;
    }
    
    void commandCallback(const std_msgs::String::ConstPtr& msg) {
        if (msg->data == "replan") {
            ROS_INFO("Received replan command");
            runAStar();
        } else if (msg->data == "regenerate") {
            ROS_INFO("Regenerating map and path");
            generateMap();
            publishAll();
        }
    }
    
    void generateMap() {
        grid_.assign(map_height_, std::vector<int>(map_width_, 0));
        
        if (random_obstacles_) {
            std::srand(static_cast<unsigned>(time(nullptr)));
            for (int y = 0; y < map_height_; ++y) {
                for (int x = 0; x < map_width_; ++x) {
                    if (std::rand() % 100 < obstacle_ratio_) {
                        grid_[y][x] = 1;
                    }
                }
            }
        }
        
        int start_grid_x = static_cast<int>((start_x_ - origin_x_) / map_resolution_);
        int start_grid_y = static_cast<int>((start_y_ - origin_y_) / map_resolution_);
        int goal_grid_x = static_cast<int>((goal_x_ - origin_x_) / map_resolution_);
        int goal_grid_y = static_cast<int>((goal_y_ - origin_y_) / map_resolution_);
        
        clearStartAndGoalArea(start_grid_x, start_grid_y);
        clearStartAndGoalArea(goal_grid_x, goal_grid_y);
    }
    
    void clearStartAndGoalArea(int gx, int gy) {
        for (int dy = -1; dy <= 1; ++dy) {
            for (int dx = -1; dx <= 1; ++dx) {
                int nx = gx + dx;
                int ny = gy + dy;
                if (nx >= 0 && nx < map_width_ && ny >= 0 && ny < map_height_) {
                    grid_[ny][nx] = 0;
                }
            }
        }
    }
    
    void publishAll() {
        publishMap();
        publishMarkers();
        runAStar();
    }
    
    void publishMap() {
        nav_msgs::OccupancyGrid map_msg;
        map_msg.header.stamp = ros::Time::now();
        map_msg.header.frame_id = frame_id_;
        map_msg.info.resolution = map_resolution_;
        map_msg.info.width = map_width_;
        map_msg.info.height = map_height_;
        map_msg.info.origin.position.x = origin_x_;
        map_msg.info.origin.position.y = origin_y_;
        map_msg.info.origin.orientation.w = 1.0;
        
        for (int y = 0; y < map_height_; ++y) {
            for (int x = 0; x < map_width_; ++x) {
                map_msg.data.push_back(grid_[y][x] * 100);
            }
        }
        map_pub_.publish(map_msg);
    }
    
    void publishMarkers() {
        visualization_msgs::Marker start_marker, goal_marker;
        start_marker.header.frame_id = frame_id_;
        start_marker.header.stamp = ros::Time::now();
        start_marker.ns = "start_goal";
        start_marker.id = 0;
        start_marker.type = visualization_msgs::Marker::SPHERE;
        start_marker.action = visualization_msgs::Marker::ADD;
        start_marker.pose.position.x = start_x_;
        start_marker.pose.position.y = start_y_;
        start_marker.scale.x = map_resolution_ * 1.5;
        start_marker.scale.y = map_resolution_ * 1.5;
        start_marker.scale.z = map_resolution_ * 1.5;
        start_marker.color.r = 0.0;
        start_marker.color.g = 1.0;
        start_marker.color.b = 0.0;
        start_marker.color.a = 1.0;
        
        goal_marker.header = start_marker.header;
        goal_marker.id = 1;
        goal_marker.pose.position.x = goal_x_;
        goal_marker.pose.position.y = goal_y_;
        goal_marker.scale = start_marker.scale;
        goal_marker.color.r = 1.0;
        goal_marker.color.g = 0.0;
        goal_marker.color.b = 0.0;
        goal_marker.color.a = 1.0;
        
        start_pub_.publish(start_marker);
        goal_pub_.publish(goal_marker);
        
        visualization_msgs::MarkerArray obstacle_markers;
        int id = 0;
        for (int y = 0; y < map_height_; ++y) {
            for (int x = 0; x < map_width_; ++x) {
                if (grid_[y][x] == 1) {
                    visualization_msgs::Marker obstacle;
                    obstacle.header.frame_id = frame_id_;
                    obstacle.header.stamp = ros::Time::now();
                    obstacle.ns = "obstacles";
                    obstacle.id = id++;
                    obstacle.type = visualization_msgs::Marker::CUBE;
                    obstacle.action = visualization_msgs::Marker::ADD;
                    obstacle.pose.position.x = origin_x_ + (x + 0.5) * map_resolution_;
                    obstacle.pose.position.y = origin_y_ + (y + 0.5) * map_resolution_;
                    obstacle.scale.x = map_resolution_;
                    obstacle.scale.y = map_resolution_;
                    obstacle.scale.z = map_resolution_ * 0.5;
                    obstacle.color.r = 0.5;
                    obstacle.color.g = 0.5;
                    obstacle.color.b = 0.5;
                    obstacle.color.a = 0.8;
                    obstacle_markers.markers.push_back(obstacle);
                }
            }
        }
        obstacles_pub_.publish(obstacle_markers);
    }
    
    void runAStar() {
        std::vector<std::pair<double, double>> path = astar_->findPath(
            start_x_, start_y_, goal_x_, goal_y_, grid_);
        
        nav_msgs::Path path_msg;
        path_msg.header.stamp = ros::Time::now();
        path_msg.header.frame_id = frame_id_;
        
        for (const auto& point : path) {
            geometry_msgs::PoseStamped pose;
            pose.header = path_msg.header;
            pose.pose.position.x = point.first;
            pose.pose.position.y = point.second;
            pose.pose.position.z = 0;
            pose.pose.orientation.w = 1.0;
            path_msg.poses.push_back(pose);
        }
        
        if (!path.empty()) {
            ROS_INFO("Path found with %zu points", path.size());
        }
        
        path_pub_.publish(path_msg);
    }
    
private:
    ros::Publisher map_pub_, path_pub_, start_pub_, goal_pub_, obstacles_pub_;
    ros::Subscriber command_sub_;
    astar_planning::AStar* astar_;
    std::vector<std::vector<int>> grid_;
    int map_width_, map_height_;
    double map_resolution_, origin_x_, origin_y_;
    double start_x_, start_y_, goal_x_, goal_y_;
    int obstacle_ratio_;
    bool random_obstacles_;
    std::string frame_id_;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "astar_node");
    AStarPlanner planner;
    ros::spin();
    return 0;
}
